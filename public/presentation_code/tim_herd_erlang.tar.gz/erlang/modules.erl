-module(modules).
-export([fun1/2, fun2/2, fun3/2]).

%% the first line MUST contain "-module(name) ". This declares the module, and names it

%% The export command makes functions available to calling code.
%% It must take a list (square brackets) of function identifiers
%% A function identifier is the function name, a /, and then the arity

%% Anything exported can be called by other modules. Anything not, cant.
%% Effectively, everything is private unless listed in export


%% To call a function in another module, use

foo:bar().

%% If one didn't want to have to type foo:, they could IMPORT from the foo module
%% like so:
-import(foo, [bar/0]).

%% This is considered bad practice, as it pollutes the local namespace
