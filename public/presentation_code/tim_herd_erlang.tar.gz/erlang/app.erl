-module(app).

%% CONTROL FUNCTION
start() ->
    spawn(fun main/0).
stop(Pid) ->
    Result = rpc(Pid, stop),
    case Result of
        {main_menu, _} ->
            rpc(Pid, stop),
            terminated;
        _ ->
            terminated
    end.


add_mode(Pid, Point) when Point ->
    rpc(Pid, add_point_mode);
add_mode(Pid, Point) when not Point ->
    rpc(Pid, add_mode).

sub_mode(Pid, Point) when Point ->
    rpc(Pid, add_point_mode);
sub_mode(Pid, Point) when not Point ->
    rpc(Pid, sub_mode).

input(Pid, NumOrPt) ->
    rpc(Pid, NumOrPt).


%% The RPC function, sends and receives for you

rpc(Pid, Request) ->
    Pid ! {self(), Request},
    receive
        {Pid, Response} ->
            Response
    end.

main(Tot, Pt) ->
    receive
        {Pid, add_mode} ->
            Pid ! entered_add_mode,
            add_mode(0),
            main();
        {Pid, add_point_mode} ->
            Pid ! entered_add_point_mode,
            add_point_mode(0,0),
            main();
        {Pid, sub_mode} ->
            Pid ! entered_sub_mode,
            sub_mode(0),
            main();
        {Pid, sub_point_mode} ->
            Pid ! entered_sub_point_mode,
            sub_point_mode(0,0),
            main();
        {Pid, stop} ->
            Pid ! terminated
        _ ->
            Pid ! invalid_mode
    end.


add_mode(Total) ->
    receive
        {Pid, N} when is_number(N) ->
            Pid ! {add_mode, {total, N+Total}},
            add_mode(N+Total);
        {Pid, _} ->
            Pid ! {main_mode, {total, Total}}
    end.

add_point_mode(XTot,YTot) ->
    receive
        {Pid, {X,Y}} when is_number(X), is_number(Y) ->
            Pid ! {add_point_mode, {point, {X+XTot, Y+YTot}}},
            add_point_mode(X+XTot, Y+YTot);
        {Pid, _} ->
            Pid ! {main_mode, {point, {XTot, YTot}}}
    end.


sub_mode(Total) ->
    receive
        {Pid, N} when is_number(N) ->
            Pid ! {sub_mode, {total, Total - N}},
            sub_mode(Total - N);
        {Pid, _} ->
            Pid ! {main_mode, {total, Total}}
    end.

sub_point_mode(XTot,YTot) ->
    receive
        {Pid, {X,Y}} when is_number(X), is_number(Y) ->
            Pid ! {sub_point_mode, {point, {XTot-X, YTot-Y}}},
            sub_point_mode(XTot-X, YTot-Y);
        {Pid, _} ->
            Pid ! {main_mode, {point, {XTot, YTot}}}
    end.


