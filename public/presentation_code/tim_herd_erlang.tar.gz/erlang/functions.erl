-module(functions).



%%A simple function

example(Param1, Param2, Param3) ->
    Param1 + Param2 + Param3.

example_1(Param1) ->
    Herp = Param1,    %% statements in function body comma-separated
    Derp = 2 * Param1,
    Herp + Derp.      %% Ends with a period

%% The last value evaluated is returned (like Ruby)


%% All functions are effectively multimethods. A function can define multiple bodies, and the first
%% signature thats matched wins

example_2(Param1, []) ->
    [Param1];
example_2(Param1, Param2) ->
    Param1 + Param2.


%% Arbitrary patterns can be matched in function headers

pattern([]) ->
    list;
pattern({A,B,C}) ->
    tuple;
pattern({A, 2, {herp, {1,2,C}}, []}) ->
    arbitrary_tuple_match;
pattern(_) ->
    default.

% Note how every body ends with ; except the last one. This is one of those stupid things.


awesome_pattern_power(Date = {Y,M,D}) ->
    yeah_we_can_do_that.

%% if you call awesome_pattern_power like so:

awesome_pattern_power({1989,11,12}).

%% Then Y,M,D, will each be bound to the individual numbers, but Date will ALSO be bound to the
%% entire tuple. HELLZ YEAH


%% MY favourite erlang pattern matching example (from "Programming Erlang" by Joe Armstrong)
%% Note: The triangle brackets mean we're pattern matching on a binary stream

parse_ipv4(<<IP_Version:4, Header_Len:4, Service_Type:8, Total_Length:16,
             ID:16, Flags:3, Fragment_Offset:13, TTL:8, Protocol:8, Header_Checksum:16,
             Source_IP:32, Dest_IP:32, Rest/binary>>) ->
    io:format("Thats right. I just parsed an entire IPv4 packet in a function header").




