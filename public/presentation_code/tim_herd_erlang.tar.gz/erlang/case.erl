-module(case).



% Case statements are quick pattern-matching for the programmer on the go

% Example shamelessly stolen from http://learnyousomeerlang.com

beach(Temp) ->
    case Temp of
        {celsius, N} when N >= 20, N =< 40 ->  %% You can still stick guards in a case expression
            'favourable';
        {kelvin, N} when N >= 293, N =< 323 ->
            'scientifically favourable';
        {fahrenheit, N} when N >= 68, N =< 104 ->
            'favourable in the US';
        _ ->  %% Remember _ is the "I don't care" matcher
            'don\'t bother'  %% NO SEMI-COLON
    end.

%% The only practical difference between the above, and doing it with separate function heads,
%% is that a case statement can only match on one variable
%% while you could do func(A,B), you would have to encapsulate those variables in
%% a tuple {A,B} to pass it to a case statement
