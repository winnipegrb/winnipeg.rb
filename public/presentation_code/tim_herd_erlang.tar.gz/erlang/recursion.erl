-module(recursion).

% Naieve factorial:

fac(N) when N == 0 ->
     1;
fac(N) when N > 0 ->
    N * fac(N-1).

% But we can improve. For large N, this will blow the stack. The Erlang VM does tail call optimization
% so lets rewrite this as a tail-recursion

smart_fac(N) ->
    smart_fac(N, 1).  % Note this is a period. That's because smart_fac/1 and smart_fac/2 are two
                      % different functions that just so happen to have the same name
smart_fac(0, Acc) ->
    Acc;
smart_fac(N,Acc) when N > 0 ->
    tail_fac(N-1, N * Acc).



%% Another example. Reverse:

naieve_reverse([]) ->
    [];
naieve_reverse([H|T]) ->  % matches a list. Head is bound to H, Tail to T
    reverse(T) ++ [H].    % append H to the reverse of T

% Since ++ is O(N) on the size of it's left operand, we can improve this. TAIL CALL TIME

smart_reverse(L) ->
    smart_reverse(L,[]).

smart_reverse([], Acc) ->
    Acc;
smart_reverse([H|T], Acc) ->
    smart_reverse(T, [H|Acc]).



%% THE CANONICAL EXAMPLE FOR WHY FUNCTIONAL PROGRAMMING LANGUAGES KICK ASS

quicksort([]) -> % An empty list is already sorted
    [];

quicksort([Pivot|Rest]) -> %%First element is pivot, rest is to be sorted
    quicksort([Smaller || Smaller <- Rest, Smaller =< Pivot]) %% List comprehension. All smaller than pivot
    ++ [Pivot] ++                                             %% Pivot in middle
    quicksort([Larger || Larger <- Rest, Larger > Pivot]).    %% List comprehension. All larger than pivot
