-module(comprehensions).

%% Unfortunately, we can only do this with finite-length lists

[X || X <- lists:seq(1,100), X =:= X*X].

% X is now the list of all numbers between 1 and 100, such that X = X^2. Which is [1]

% You can use as many generators as you like, one per variable

[X + Y || X <- [1,2,3,4,5], Y <- [2,4,6,8,10]}.

% Generates Cartesian Product: [3,5,7,9,11,4,6,8,10,12,5,7,9,11,13,6,8,10,12,14,7,9,11,13,15]

% You can pattern match on the generator expression

[X + Y || {X, Y} <- [{1,2}, {2,4}, {3,6}, {4,8}, {5,10}]].

% Generates [3,6,9,12,15]

