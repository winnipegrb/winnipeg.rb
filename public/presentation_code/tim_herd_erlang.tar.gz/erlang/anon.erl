-module(anon).


increment(X) ->
    X + 1.


%% Lets implement map!

map(_, []) -> %% Edge Case
    [];
map(Func, [H|T]) ->
    [Func(H) | map(Func,T)].

%% I want to increment my list
List = [1,2,3,4,5].

NewList = map(increment/1, List).


%Hmm... I think I'd rather square the values in that list. But I don't want to define a new func

SquareList = map(fun(X) -> X*X; end, List)

