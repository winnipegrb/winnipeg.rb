-module(guards).



guard(Age) when Age < 12 ->  %% Normal Guard
    herp;
guard(Age) when Age >= 12, Age =< 14 ->  %% commas mean all criteria must be met (they're ANDs)
    a;
guard(Age) when Age > 14, Age =< 21; Age =:= 42 -> %% semi-colons mean at least one must be met
    derp;                                          %% (they're ORs)
guard(_) ->
    default.  %incidentally _ is the "I don't care" matching token.





%% GUARD PATTERNS

guard_pattern(X) ->
    if X < 2 ->
            io:format("Less than 2"); %%BTW this prints to standard out. It's got retarded syntax too!
       X > 2, X =< 5 ->
            io:format("Between (2,5]");
       X == 7; X =:= 9 ->
            io:format("It's either 7, 7.0, or 9");
       X == herpaderp ->
            io:format("It's the atom herpaderp");
       true ->
            default
    end.


%% One of the branches of the if MUST succeed. It is a compiler error if no branches succeed

gp_2(X) ->
    if X < 2 ->
            herp;
       X > 4 ->
            derp;
    end.

%% This generates a compile error

%% If blocks return values (like ruby), so this is valid
gp_3(X) ->
    Sign = if X < 0 ->
                   negative;
              true ->
                   positive
           end,             %% NOTE THE COMMA
    io:format("The sign is ~s", [Sign]).  %%Told you the output syntax was retarded


