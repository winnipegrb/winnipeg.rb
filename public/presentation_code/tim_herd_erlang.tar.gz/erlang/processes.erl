-module(processes).


%% A receive block.
receive_example ->
     receive
         foo ->
             io:format("Received Foo~n");
         bar ->
             io:format("Received Bar~n");
         _ ->
             io:format("Unrecognized Message~n")
     end.

Pid = spawn(receive_example/0).

Pid ! foo.  %causes the process to receive message, and terminate


%% Receive blocks work on pattern matching. They can also have guards

receive_ex2 ->
    receive
        {cm, Val} when Val =< 200 ->
            io:format("Less than 200 cm~n");
        {m, Val} when Val =< 2 ->
            io:format("Still less than 200 cm~n");
        _ ->
            io:format("Invalid message!~n")
    end.

Pid = spawn(receive_ex2/0).
Pid ! {cm, 111}.



%% Normal Paradigm

%% Since message passing is asynchronous, the only way that a process can reply is if
%% it gets a return address. This is often done like so:

reply_example ->
    receive
        {Pid, foo} ->
            Pid ! "Received Foo";
        {Pid, bar} ->
            Pid ! "Received Bar";
        {Pid, _} ->
            Pid ! "Invalid message"
    end.

Pid = spawn(reply_example/0).
Pid ! {self(), foo}.


%% Receive Timeout

%% Normally, a process will sleep indefinitely until it receives a message. Alternatively,
%% you can specify a timeout. The process will wake after Timeout ms, and continue on

timeout_ex ->
    receive
        {Pid, Val} ->
            Pid ! Val %% echo back the value
         after 3000 ->
                 io:format("OMG I WAITED AND YOU NEVER CALLED~n")
         end.
spawn(timeout_ex/0).




